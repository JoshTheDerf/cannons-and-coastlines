# Queen's Fleet and Corsairs print list

What to print from this download, and how. PRINTING.pdf has the same, with pictures. Online: https://cannonsandcoastlines.com/print-list/base-set

## Queen's Fleet

3 frigates with 4 fittings each (2 masts, 2 cargo).

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Hull | ship-queens-fleet.stl | 3 | Pale blue-grey or brown PLA | No |  |
| Mast | mast.stl | 6 | Brown | No |  |
| Sail | sail.stl | 6 | White | No |  |
| Cargo | cargo.stl | 6 | Brown | No |  |
| Movement wheel | movement-wheel.stl | 3 | Any | No |  |
| Cannon | cannon.stl | 4 | Black | No |  |
| Cannonball | cannonball.stl | 10 | Something bright, like neon green or orange | No |  |

## Corsairs

3 sloops with 3 fittings each (2 masts, 1 cargo).

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Hull | ship-corsair.stl | 3 | Black PLA | No |  |
| Mast | mast.stl | 6 | Black PLA | No |  |
| Torn sail | sail-damaged.stl | 6 | Black PLA | No | Or sail.stl. |
| Cargo | cargo.stl | 3 | Brown | No |  |
| Movement wheel | movement-wheel.stl | 3 | Any | No |  |
| Cannon | cannon.stl | 4 | Black | No |  |
| Cannonball | cannonball.stl | 10 | Something bright, like neon green or orange | No |  |

## Islands, coins and terrain

### Per player

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Coins | coin-*.stl | 20 | Gold | No | 5 Brace for Impact, 2 Full Sail, 2 Evasive Maneuvers, 5 Skilled Gunner, 4 Repair Crew, 2 Boarding Party. |
| Island | island.stl | 1–2 | Green, sand or grey | No | Or island-topper.stl on a box or a mug. |
| Short mast | mast-short.stl | 1–2 | Brown | No | One per island |

### Per table

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Rock | rock1.stl | 2–6 | Grey | No | With three or more players, 2 per fleet. |
| Reef | reef.stl | 0–2 | Pale pink | No |  |
| Wind dial | wind-dial-*.stl | 1 each | Any | No | Optional. A steel M8 washer spins better. |
| Fit test | ship-tolerance-test.stl | 1 | Anything | No | Print it first. |

## Settings

| Setting | Value |
| --- | --- |
| Material | PLA |
| Layer height | 0.12–0.20 mm (0.16 mm recommended) |
| Z contouring | On |
| Orientation | Use your slicer's auto-orient. |
| Infill | 10% or more |

## Printing and putting it together

1. Print the fit test (ship-tolerance-test.stl in the base set) first. If a peg is loose, scale it up 0.5 to 1% in your slicer. If it's tight, sand it a bit.
2. Print a spare cannon or two.
3. Stretch a 10 mm rubber band or silicone cable tie around each wheel's rim and push the wheel into the slot under the stern. It should be snug but still spin, and it stays in.
4. Plug the fittings into the deck.
5. Slide the sails down over the masts, and a paper flag into the slot at the top of a mast.
6. Plug a short mast into each island for its flag.

## What a game needs

Each player needs a fleet printed from its list, 20 coins, one or two islands with a short mast each, the faction card and some paper flags.

The table needs 2 to 6 rocks and reefs, and the wind dial if you want it.

You also need a 10 mm rubber band or silicone cable tie for every wheel and a cloth bag for the coins.

The shop page is https://cannonsandcoastlines.com/shop/base-set-files, and the print guide is at https://cannonsandcoastlines.com/print-guide.
