# Queen's Fleet and Corsairs print list

What to print from this download, and how. PRINTING.pdf has the same, with pictures. Online: https://cannonsandcoastlines.com/print-list/base-set

## Queen's Fleet

3 frigates with 4 fittings each (2 masts, 2 cargo).

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Hull | ship-queens-fleet.stl | 3 | Pale blue-grey or brown | No |  |
| Mast | mast.stl | 6 | Brown | No |  |
| Sail | sail.stl | 6 | White | No |  |
| Cargo | cargo.stl | 6 | Brown | No |  |
| Movement wheel | movement-wheel.stl | 3 | Any | No |  |
| Cannon | cannon.stl | 4 | Black | No |  |
| Cannonball | cannonball.stl | 10 | Something bright, like neon green or orange | No |  |

## Corsairs

3 sloops with 3 fittings each (2 masts, 1 cargo).

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Hull | ship-corsair.stl | 3 | Black | No |  |
| Mast | mast.stl | 6 | Black | No |  |
| Torn sail | sail-damaged.stl | 6 | Black | No | Or sail.stl. |
| Cargo | cargo.stl | 3 | Brown | No |  |
| Movement wheel | movement-wheel.stl | 3 | Any | No |  |
| Cannon | cannon.stl | 4 | Black | No |  |
| Cannonball | cannonball.stl | 10 | Something bright, like neon green or orange | No |  |

## Islands, coins and terrain

### Per player

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Coins | coin-*.stl | 20 | Gold | No | 5 Brace for Impact, 2 Full Sail, 2 Evasive Maneuvers, 5 Skilled Gunner, 4 Repair Crew, 2 Boarding Party. |
| Island | island.stl | 1–2 | Green, sand or grey | No | Or island-topper.stl on a box or a mug. |
| Short mast | mast-short.stl | 1–2 | Brown | No | One per island |

### Per table

| Part | File | Qty | Color | Supports | Notes |
| --- | --- | --- | --- | --- | --- |
| Rock | rock1.stl | 2–6 | Grey | No | With three or more players, 2 per fleet. |
| Reef | reef.stl | 0–2 | Pale pink | No |  |
| Wind dial | wind-dial-*.stl | 1 each | Any | No | For the optional Trade Winds rule. A steel M8 washer spins better. |
| Fit test | ship-tolerance-test.stl | 1 | Anything | No | Print it first. |

## Printing

| Setting | Value |
| --- | --- |
| Material | PLA. PETG works for the Shadow Fleet too. |
| Layer height | 0.16 mm or lower |
| Z contouring | On |
| Infill | 10% or more |

- Lay each cannon so the flex arm's layers run across the bend, and print a spare or two.
- Print masts lying flat.

## Putting It Together

Everything press-fits, so you don't need glue or tools. The wheel is the only part you fit once and leave in.

### The ship (once)

1. Stretch a thin **rubber band** around the rim of the **wheel**.
2. Push the wheel into the slot under the stern. It should be snug but still spin.

### Fittings (every game)

- **Masts**, **cargo** and **barrels** plug into the deck.
- **Sails** slide down over the masts.
- Each hit knocks off one fitting. How many you have is on your faction card. A bare hull sinks on the next hit.

### Cannons

- Plug the **cannon** into any open slot on a ship or an island.
- Drop in a **cannonball** and press the arm down until it fires.
- You can pull a cannon and move it to another slot between shots.

### Flags and islands

- Slide a paper flag into the slot at the top of a **mast**.
- **Islands** sit straight on the table. Plug a **short mast** in to fly your flag.
- **Island toppers** go on top of anything the right height. Same cannon slots and flag holes as a ship.

Every piece, with pictures: https://cannonsandcoastlines.com/parts

## What a game needs

Each player brings a fleet printed from its list, 20 coins, one or two islands with a short mast each, the faction card and some paper flags.

The table needs 2 to 6 rocks and reefs. With three or more players, put a rock at each end of every fleet's line. Add the wind dial if you play Trade Winds. A 6 ft round table or a 6 or 8 ft folding table works well.

You also need a thin rubber band for every wheel and a cloth bag for the coins.
