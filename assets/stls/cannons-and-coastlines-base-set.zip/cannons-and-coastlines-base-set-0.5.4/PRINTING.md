# Print guide: Queen's Fleet and Corsairs

The settings and colors for the files in this download. The online version is at https://cannonsandcoastlines.com/print-guide.

## Settings for everything

| Setting | Value |
| --- | --- |
| Material | PLA. PETG works for the Shadow Fleet too. |
| Layer height | 0.16 mm or lower |
| Z contouring | On |
| Infill | 10% or more |
| Supports | Off. Only the Shadow Fleet and Treasure Fleet need them. |

The add-on fleet downloads have the hulls and each fleet's own parts. The masts, cargo, cannons and wheels come from the free base set.

## Colors by part

| Part | Color |
| --- | --- |
| Masts and cargo | Brown |
| Industry turrets and smokestacks | Rust brown or steel blue |
| Cannons | Black |
| Sails | White |

The Corsairs and the Shadow Fleet are the exceptions. Print their masts and sails in the same color as the hull.

## Queen's Fleet

| Setting | Value |
| --- | --- |
| Hull | Pale blue-grey or brown |
| Masts and sails | Brown masts, white sails |
| Supports | Off |
| Material | PLA |

Online: https://cannonsandcoastlines.com/print-guide#queens-fleet

## Corsairs

| Setting | Value |
| --- | --- |
| Hull | Black |
| Masts and sails | Same color as the hull |
| Supports | Off |
| Material | PLA |

Online: https://cannonsandcoastlines.com/print-guide#corsairs

## Files

- barrel.stl
- cannon.stl
- cannonball.stl
- cargo.stl
- coin-boarding-party.stl
- coin-brace-for-impact.stl
- coin-evasive-maneuver.stl
- coin-full-sail.stl
- coin-repair-crew.stl
- coin-skilled-gunner.stl
- flag-corsairs.svg
- flag-queens-fleet.svg
- island-topper.stl
- island.stl
- mast-short.stl
- mast.stl
- movement-wheel.stl
- reef.stl
- rock1.stl
- sail-damaged.stl
- sail.stl
- ship-corsair.stl
- ship-queens-fleet.stl
- ship-tolerance-test.stl
- wind-dial-base.stl
- wind-dial-cap.stl
- wind-dial-vane.stl
- wind-dial-washer.stl

## Putting It Together

Everything press-fits, so you don't need glue or tools. The wheel is the only part you fit once and leave in.

### The ship (once)

1. Stretch a thin **rubber band** around the rim of the **wheel**.
2. Push the wheel into the slot under the stern. It should be snug but still spin.

### Fittings (every game)

- **Masts**, **cargo** and **barrels** plug into the deck.
- **Sails** slide down over the masts.
- Each hit knocks off one fitting. How many you have is on your faction card. A bare hull sinks on the next hit.

### Cannons

- Plug the **cannon** into any open slot on a ship or an island.
- Drop in a **cannonball** and press the arm down until it fires.
- You can pull a cannon and move it to another slot between shots.

### Flags and islands

- Slide a paper flag into the slot at the top of a **mast**.
- **Islands** sit straight on the table. Plug a **short mast** in to fly your flag.
- **Island toppers** go on top of anything the right height. Same cannon slots and flag holes as a ship.

### Coins

There's nothing to build. Just print them and drop them in a cloth bag. Each player adds 20 at setup.

### Fit

Print the **fit test** first. If a peg is loose, scale it up **0.5 to 1%** in your slicer. If it's tight, sand it a bit. If masts won't seat at all, your nozzle is probably too close to the bed.

Every piece, with pictures: https://cannonsandcoastlines.com/parts
